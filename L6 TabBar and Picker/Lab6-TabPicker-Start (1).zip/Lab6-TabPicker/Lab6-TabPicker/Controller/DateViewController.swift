//
//  ViewController.swift
//  Lab6-TabPicker
//
//  Created by mm on 24/12/2567 BE.
//

import UIKit

class DateViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

