//
//  Message.swift
//  Lab9-6614110014
//
//  Created by MII-MAC-21 on 6/2/2568 BE.
//  Copyright © 2568 BE Angela Yu. All rights reserved.
//

struct Message {
    let sender: String
    let body: String
}
