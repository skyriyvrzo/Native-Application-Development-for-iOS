//
//  BMI.swift
//  Lab5-6614110014
//
//  Created by MII-MAC-21 on 19/12/2567 BE.
//  Copyright © 2567 BE Angela Yu. All rights reserved.
//

import UIKit

struct BMI {
    let value: Float
    let advice: String
    let color: UIColor
}
